import java.util.*;
/**
 * BorrowerDatabase class.
 *
 * @author (Zhoubin Xu)
 * @version (V1)
 */
public class BorrowerDatabase
{
    // instance variables - replace the example below with your own
    private ArrayList<Borrower> borrowerList;

    /**
     * Constructor for objects of class BorrowerDatabase
     */
    public BorrowerDatabase()
    {
        // initialise instance variables
        borrowerList = new ArrayList<>();
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void displayBorrowers()
    {
        // asks each Book object to display its contents
        // - what if the list is empty?
        if (borrowerList.isEmpty() == false)
            for (Borrower currentBorrower : borrowerList)
                currentBorrower.display();
    }
    
    public void addNewBorrower()
    {
        System.out.println("Please enter new borrower's name: ");
        Scanner in = new Scanner(System.in);
        String borrowerName = in.nextLine();
        System.out.println("Please enter borrower's id: ");
        int borrowerId = in.nextInt();
        System.out.println("Please enter borrower's age: ");
        int borrowerAge = in.nextInt();
        borrowerList.add(new Borrower(borrowerName, borrowerId, borrowerAge));        
    }
    
    public int findBorrower(int borrowerId)
    {
        int index = -1;

        for (Borrower currentBorrower : borrowerList)
        {
            if (currentBorrower.getId() == borrowerId)
            {
                index = borrowerList.indexOf(currentBorrower);
                return index;
            }  
        }
        return index;
    }
    
    public boolean borrowOneBook(int borrowerId, Book myBook)
    {
        if (borrowerList.get(findBorrower(borrowerId)).borrowBook(myBook))
            return true;
            
        return false;
    }
    
    public boolean returnOneBook(int borrowerId, Book myBook)
    {
        if (borrowerList.get(findBorrower(borrowerId)).returnBook(myBook))
            return true;
            
        return false;
    }   
}

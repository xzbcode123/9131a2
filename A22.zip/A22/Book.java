
/**
 * Book Class.
 *
 * @author (Zhoubin Xu)
 * @version (V1)
 */
public class Book
{
    private String title;
    private String author;
    private String rating;

    /**
     * Constructor for objects of class Book
     */
    public Book()
    {
        // initialise instance variables
        title = "Book Title";
        author = "Book Author";
        rating = "General";
    }
    
    public Book(String bookTitle, String bookAuthor, String rating)
    {
        if (notContainCommas(bookTitle) && notContainCommas(bookAuthor) && ratingValidation(rating))
        {
            title = "Book Title";
            author = "Book Author";
            rating = "General";            
        }
    }
    
    public String getBookTitle()
    {
        return title;
    }
    
    public String getAuthor()
    {
        return author;
    }
    
    public String getRating()
    {
        return rating;
    }
    
    public void changeTitle(String str)
    {
        if (notContainCommas(str))
            title = str;
    }
    
    public void changeAuthor(String str)
    {
        if (notContainCommas(str))
            author = str;
    }
    
    public void changeRating(String str)
    {
        if (ratingValidation(str))
            rating = str;
    }
    
    public boolean isCommas(char myChar)
    {
        return myChar == ',';
    }
    
    public void display()
    {
        System.out.println(title + "," + author + "," + rating);
    }
    
    /**
     * method which returns ture if input string not empty 
     * and not contain commas
     */
    public boolean notContainCommas(String str)
    {
        if (str == null || str.length() == 0)
            return false;
        for (int i = 0; i < str.length(); i++)
        {
            if (isCommas(str.charAt(i)) == true)
                return false;
        }
        return true;
    }
    
    public boolean ratingValidation(String str)
    {
        if (str == null)
            return false;
          
        return str.equals("General") || str.equals("Adult");
    }    
}

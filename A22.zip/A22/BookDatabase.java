import java.util.*;
/**
 * BookDatabase clss.
 *
 * @author (Zhoubin Xu)
 * @version (V1)
 */
public class BookDatabase
{
    // instance variables - replace the example below with your own
    private ArrayList<Book> bookList;

    /**
     * Constructor for objects of class BookDatabase
     */
    public BookDatabase()
    {
        // initialise instance variables
        bookList = new ArrayList<>();
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void displayBooks()
    {
        // asks each Book object to display its contents
        // - what if the list is empty?
        if (bookList.isEmpty() == false)
            for (Book currentBook : bookList)
                currentBook.display();
    }
    
    public void addBook()
    {
        System.out.println("Please enter the book's title: ");
        Scanner in = new Scanner(System.in);
        String bookTitle = in.nextLine();
        System.out.println("Please enter author's name: ");
        String authorName = in.nextLine();
        System.out.println("Please enter book's rating: ");
        String bookRating = in.nextLine();
        bookList.add(new Book(bookTitle, authorName, bookRating));        
    }
    
    public int findBook(String bookName)
    {
        int index = -1;

        for (Book currentBook : bookList)
        {
            if (currentBook.getBookTitle().equals(bookName))
            {
                index = bookList.indexOf(currentBook);
                return index;
            }  
        }
        return index;
    }
}

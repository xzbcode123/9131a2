
/**
 * Write a description of class MyLibrary here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MyLibrary
{
    // instance variables - replace the example below with your own
    private BorrowerDatabase MyBorrowerDatabase;
    private BookDatabase MyBookDatabase;

    /**
     * Constructor for objects of class MyLibrary
     */
    public MyLibrary()
    {
        // initialise instance variables
        MyBorrowerDatabase = new BorrowerDatabase();
        MyBookDatabase = new BookDatabase();
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void displayMainMenu()
    {
        System.out.println("Welcome to the My Library");
        System.out.println("=========================");
        System.out.println("(1) Register New Borrower");
        System.out.println("(2) Manage Borrower");
    }
}

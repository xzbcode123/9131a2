import java.util.*;
/**
 * Borrower Class.
 *
 * @author (Zhoubin Xu)
 * @version (V1)
 */
public class Borrower
{
    private String name;
    private int id;
    private int age;
    private ArrayList<Book> myBookList;
    
    /**
     * Constructor for objects of class Borrower
     */
    public Borrower()
    {
        name = "Borrower Name";
        id = 0;
        age = 0;
        myBookList = new ArrayList<>();
    }
    
    public Borrower(String nameStr, int myId, int myAge)
    {
        if (nameValidation(nameStr) && idValidation(myId) && ageValidation(myAge))
        {
            name = nameStr;
            id = myId;
            age = myAge;
            myBookList = new ArrayList<>();
        }
    }

    public String getBorrowerName()
    {
        return name;
    }
    
    public int getId()
    {
        return id;
    }
    
    public int getAge()
    {
        return age;
    }
    
    public ArrayList<Book> getMyBooKlist()
    {
        return myBookList;
    }
    
    public void changeName(String str)
    {
        if (nameValidation(str))
            name = str;
    }
    
    public void changeId(int newId)
    {
        if (idValidation(newId))
            id = newId;
    }
    
    public void changeAge(int newAge)
    {
        if (ageValidation(newAge))
            age = newAge;
    }
    
    public boolean borrowBook(Book myBook)
    {
        if (myBookList.size() >= 2)
        {
            System.out.println("* Borrower already have two books!");
            return false;
        }
        else if (myBook.getRating().equals("Adult") && age <= 18)
        {
            System.out.println("* Only person with age above 18 can borrow adult rating book!");            
            return false;
        }
        else
        {
            myBookList.add(myBook);
            return true;
        }
    }
    
    public boolean returnBook(Book myBook)
    {
        if (myBookList == null)
            return false;
            
        if (myBookList.remove(myBook) == false)
        {
            System.out.println("error: Borrower do not have the book!");
            return false;
        }
        else
            return true;
    }
    
    public void display()
    {
        System.out.println(name + "," + id + "," + age);
        if (myBookList.isEmpty() == false)
        {
            for (Book currentBook : myBookList)
                currentBook.display();
        }
    }
    
    public boolean idValidation(int myId)
    {
        if (myId >= 1 && myId <= 100)
            return true;
        return false;
    }
    
    public boolean ageValidation(int myAge)
    {
        if (myAge > 5 && myAge < 110)
            return true;
        return false;
    }
    
    /**
     * Method which determain if a character is alphabetic or is a space.
     */     
    public boolean isAlphabeticOrSpace(char myChar)
    {
        return Character.isAlphabetic(myChar) || Character.isWhitespace(myChar);
    }
        
    /**
     * Method which determain if a string matches the naming requirement.
     */     
    public boolean nameValidation(String myName)
    {
        if (myName == null || myName.trim().length() == 0) //empty or all space
            return false;
        for (int i = 0; i < myName.length(); i++) // not alphabetic or space
        {
            if (isAlphabeticOrSpace(myName.charAt(i)) == false)
            return false;
        }
        return true;
    }
}
